package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class PathFinderCommand extends CommandBase {

    private static final Minecraft mc = Minecraft.getMinecraft();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean isWalking = new AtomicBoolean(false);

    @Override
    public String getCommandName() {
        return "walk";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/walk <x> <y> <z>";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length != 3) {
            sender.addChatMessage(new ChatComponentText("Invalid arguments! Use /walk <x> <y> <z>"));
            return;
        }

        try {
            isWalking.set(false);

            int targetX = Integer.parseInt(args[0]);
            int targetY = Integer.parseInt(args[1]);
            int targetZ = Integer.parseInt(args[2]);

            BlockPos start = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
            BlockPos goal = new BlockPos(targetX, targetY, targetZ);

            sender.addChatMessage(new ChatComponentText("Finding path..."));

            executor.submit(() -> {
                NodeData startNode = new NodeData(start, 0.0, false);
                NodeData goalNode = new NodeData(goal, 0.0, false);
                PathFinder pathFinder = new PathFinder(startNode, goalNode);
                List<Node> path = pathFinder.findPath();

                mc.addScheduledTask(() -> {
                    if (path.isEmpty()) {
                        sender.addChatMessage(new ChatComponentText("§cNo valid path found!"));
                        return;
                    }

                    sender.addChatMessage(new ChatComponentText("§aPath found! Length: " + path.size() + " blocks"));
                    isWalking.set(true);
                    walkAlongPath(path);
                });
            });

        } catch (NumberFormatException e) {
            sender.addChatMessage(new ChatComponentText("Invalid number format! Use /walk <x> <y> <z>"));
        }
    }

    private void walkAlongPath(List<Node> path) {
        executor.submit(() -> {
            try {
                isWalking.set(true);
                // Hold down the forward key
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), true);


                for (Node node : path) {
                    if (!isWalking.get()) {
                        releaseAllKeys();
                        break;
                    }

                    BlockPos targetPos = node.data.pos;
                    mc.addScheduledTask(() -> {
                        double targetX = targetPos.getX() + 0.5;
                        double targetZ = targetPos.getZ() + 0.5;

                        double deltaX = targetX - mc.thePlayer.posX;
                        double deltaZ = targetZ - mc.thePlayer.posZ;

                        // Calculate target yaw (only yaw, no pitch)
                        float targetYaw = (float) (Math.atan2(deltaZ, deltaX) * (180.0 / Math.PI)) - 90.0F;

                        // Get the current yaw
                        float startYaw = mc.thePlayer.rotationYaw;

                        new HeadTurnTask(startYaw, mc.thePlayer.rotationPitch, targetYaw, 0, 10, () -> {
                            // After head turns, move the player using keybinds
                            if (!mc.thePlayer.openContainer.equals(mc.thePlayer.inventoryContainer)) {
                                releaseAllKeys();
                                return;
                            }
                            updateMovementKeys(deltaX, deltaZ);
                        }).start();
                    });

                    // Wait until player is close enough to the target
                    while (isWalking.get() && mc.thePlayer != null &&
                            mc.thePlayer.getDistance(targetPos.getX() + 0.5, targetPos.getY(), targetPos.getZ() + 0.5) > 0.5) {
                        // Check if inventory is open
                        if (!mc.thePlayer.openContainer.equals(mc.thePlayer.inventoryContainer)) {
                            releaseAllKeys();
                            break;
                        }
                        Thread.sleep(50);
                    }

                    Thread.sleep(50); // Small delay between nodes
                }

                mc.addScheduledTask(() -> {
                    releaseAllKeys();
                    isWalking.set(false);
                    mc.thePlayer.addChatMessage(new ChatComponentText("§aReached the destination."));
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
                releaseAllKeys();
            }
        });
    }

    private void updateMovementKeys(double deltaX, double deltaZ) {
        // Calculate movement based on player's rotation
        double forward = -Math.sin(Math.toRadians(mc.thePlayer.rotationYaw)) * deltaX + Math.cos(Math.toRadians(mc.thePlayer.rotationYaw)) * deltaZ;
        double strafe = Math.cos(Math.toRadians(mc.thePlayer.rotationYaw)) * deltaX + Math.sin(Math.toRadians(mc.thePlayer.rotationYaw)) * deltaZ;

        // Set movement keys without releasing them constantly
        if (Math.abs(forward) > 0.1) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), forward > 0);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), forward < 0);
        }
        if (Math.abs(strafe) > 0.1) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), strafe > 0);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), strafe < 0);
        }
    }

    private void releaseAllKeys() {
        mc.addScheduledTask(() -> {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
        });
    }

    private class HeadTurnTask {
        private final float startYaw;
        private final float startPitch;
        private final float targetYaw;
        private final float targetPitch;
        private final int durationTicks;
        private final Runnable onComplete;
        private int ticksPassed;

        public HeadTurnTask(float startYaw, float startPitch, float targetYaw, float targetPitch, int durationTicks, Runnable onComplete) {
            this.startYaw = startYaw;
            this.startPitch = startPitch;
            this.targetYaw = targetYaw;
            this.targetPitch = 0; // Force pitch to 0 (looking straight ahead)
            this.durationTicks = durationTicks;
            this.onComplete = onComplete;
            this.ticksPassed = 0;
        }

        public void start() {
            mc.addScheduledTask(this::update);
        }

        private void update() {
            if (ticksPassed < durationTicks) {
                // Calculate progress (0.0 to 1.0) for interpolation
                float progress = (float) ticksPassed / durationTicks;

                // Linearly interpolate yaw and pitch
                float interpolatedYaw = startYaw + progress * (targetYaw - startYaw);
                float interpolatedPitch = startPitch + progress * (targetPitch - startPitch);

                // Update player's yaw and pitch
                mc.thePlayer.rotationYaw = interpolatedYaw;
                mc.thePlayer.rotationPitch = interpolatedPitch;

                // Increment ticks passed
                ticksPassed++;

                // Schedule the next tick
                mc.addScheduledTask(this::update);
            } else {
                // Final update to ensure the head is exactly at the target
                mc.thePlayer.rotationYaw = targetYaw;
                mc.thePlayer.rotationPitch = targetPitch;

                // Execute the onComplete action (e.g., move the player) after head turn
                if (onComplete != null) {
                    onComplete.run();
                }
            }
        }
    }

    public class Node {
        public NodeData data;
        public double gCost;
        public double hCost;
        public double fCost;
        public Node parent;

        public Node(NodeData nodeData, double g, double h, Node p) {
            this.data = nodeData;
            this.gCost = g;
            this.hCost = h;
            this.fCost = g + h;
            this.parent = p;
        }
    }

    public class NodeData {
        public BlockPos pos;
        public double movement;
        public boolean isCustomNode;

        public NodeData(BlockPos pos, double movement, boolean customNode) {
            this.pos = pos;
            this.movement = movement;
            this.isCustomNode = customNode;
        }
    }

    public class PathFinder {
        private final Node start;
        private final Node goal;
        private final HashMap<BlockPos, Node> openSet = new HashMap<>();
        private final HashMap<BlockPos, Node> closedSet = new HashMap<>();
        private final List<BlockPos> directions;

        public PathFinder(NodeData startNode, NodeData goalNode) {
            this.start = new Node(startNode, 0.0, calculateHeuristic(startNode.pos, goalNode.pos), null);
            this.goal = new Node(goalNode, Double.MAX_VALUE, 0.0, null);
            this.openSet.put(this.start.data.pos, this.start);

            this.directions = Arrays.asList(
                    new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0),
                    new BlockPos(0, 0, 1), new BlockPos(0, 0, -1),
                    new BlockPos(1, 0, 1), new BlockPos(-1, 0, 1),
                    new BlockPos(1, 0, -1), new BlockPos(-1, 0, -1),
                    new BlockPos(0, 1, 0), new BlockPos(0, -1, 0)
            );
        }

        private double calculateHeuristic(BlockPos start, BlockPos goal) {
            double dx = Math.abs(start.getX() - goal.getX());
            double dy = Math.abs(start.getY() - goal.getY());
            double dz = Math.abs(start.getZ() - goal.getZ());

            return Math.sqrt(2) * Math.min(dx, dz) + Math.abs(dx - dz) + dy;
        }

        private boolean isValidPosition(BlockPos pos) {
            return !mc.theWorld.isAirBlock(pos.down()) && mc.theWorld.isAirBlock(pos) &&
                    mc.theWorld.isAirBlock(pos.up());
        }

        public List<Node> findPath() {
            while (!openSet.isEmpty()) {
                Node currentNode = getLowestFCostNode();

                if (currentNode.data.pos.equals(goal.data.pos)) {
                    goal.parent = currentNode.parent;
                    goal.gCost = currentNode.gCost;
                    return retracePath();
                }

                openSet.remove(currentNode.data.pos);
                closedSet.put(currentNode.data.pos, currentNode);

                for (BlockPos direction : directions) {
                    BlockPos neighborPos = currentNode.data.pos.add(direction);
                    if (closedSet.containsKey(neighborPos)) continue;

                    if (!isValidPosition(neighborPos)) continue;

                    double tentativeGCost = currentNode.gCost + currentNode.data.movement;
                    if (!openSet.containsKey(neighborPos)) {
                        NodeData neighborData = new NodeData(neighborPos, 1.0, false);
                        Node neighborNode = new Node(neighborData, tentativeGCost,
                                calculateHeuristic(neighborPos, goal.data.pos), currentNode);
                        openSet.put(neighborPos, neighborNode);
                    } else {
                        Node neighborNode = openSet.get(neighborPos);
                        if (tentativeGCost < neighborNode.gCost) {
                            neighborNode.gCost = tentativeGCost;
                            neighborNode.parent = currentNode;
                        }
                    }
                }
            }
            return Collections.emptyList();
        }

        private Node getLowestFCostNode() {
            return openSet.values().stream().min(Comparator.comparingDouble(n -> n.fCost)).orElse(null);
        }

        private List<Node> retracePath() {
            List<Node> path = new ArrayList<>();
            Node currentNode = goal;

            while (currentNode != null) {
                path.add(currentNode);
                currentNode = currentNode.parent;
            }

            Collections.reverse(path);
            return path;
        }
    }
}
